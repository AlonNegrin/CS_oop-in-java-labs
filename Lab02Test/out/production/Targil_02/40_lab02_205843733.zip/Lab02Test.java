
public class Lab02Test {

    public static void main(String[] args) {
    Table t1 = new Table(50,50);
    t1.display(20,30,15,35);
    }
}
