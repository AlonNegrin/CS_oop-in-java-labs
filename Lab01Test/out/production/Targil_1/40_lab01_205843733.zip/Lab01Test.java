public class Lab01Test {

    public static void main(String[] args) {
        Picture p1 = new Picture();
        p1.draw();
        p1.sunSet();
    }

}
