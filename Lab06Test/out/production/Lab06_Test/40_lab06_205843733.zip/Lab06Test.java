import java.io.FileNotFoundException;

public class Lab06Test {

    public static void main(String[] args) throws FileNotFoundException {
        CapitalGame game = new CapitalGame();
        game.play();
    }
}
