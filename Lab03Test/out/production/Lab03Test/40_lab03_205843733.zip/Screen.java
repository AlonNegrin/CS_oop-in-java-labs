public class Screen {
    public Screen() {
    }

    public void displayGreeting() {
        System.out.println("Welcome!");
    }

    public void displayAcctPrompt() {
        System.out.print("Please enter your account number: ");
    }

    public void displayPwPrompt() {
        System.out.print("Enter your PIN: ");
    }

    public void displayMainMenu() {
        System.out.println("Main menu");
        System.out.println("\t1 - View my balance");
        System.out.println("\t2 - Withdraw cash");
        System.out.println("\t3 - Deposit funds");
        System.out.println("\t4 - Exit");
        System.out.print("Enter a choice: ");
    }

    public void displayWithdrawalMenu() {
        System.out.println("Withdrawal menu");
        System.out.println("\t1 - $20\t\t4 - $100");
        System.out.println("\t2 - $40\t\t5 - $200");
        System.out.println("\t3 - $60\t\t6 - Cancel transaction");
        System.out.print("Choose a withdrawal amount: ");
    }

    public void displayDepositMenu() {
        System.out.print("How much would you like to deposit?");

    }

    public void displayDeposit(double depo) {
        System.out.printf("Deposit %.1f\n", depo);
    }

    public void displayBalance(Db db) {
        System.out.printf("Your Balance is: %.1f\n", db.getBalance());

    }

    public void displayGoodbye() {
        System.out.println("Good bye!");
    }

    public void error(String s) {
        System.err.println(s);
    }
}
