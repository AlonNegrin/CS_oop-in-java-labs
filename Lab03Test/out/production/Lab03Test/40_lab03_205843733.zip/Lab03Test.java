public class Lab03Test {

    public static void main(String[] args) {
        Atm atm = new Atm( "myDatabase" );
        atm.go();
    }
}
